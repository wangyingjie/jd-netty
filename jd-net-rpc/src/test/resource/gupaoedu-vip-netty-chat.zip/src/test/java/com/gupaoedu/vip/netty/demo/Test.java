package com.gupaoedu.vip.netty.demo;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		SCaptcha s=new SCaptcha();
//		String path="C:\\Users\\Administrator\\Desktop\\"+System.currentTimeMillis()+".png";
//		try {
//			s.write(path);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		
//		System.out.println( path );
		
		Integer  a1 = 123;
		Integer  a2 = 123;
		Integer a3 = new Integer(123);
		Integer a4 = new Integer(123);
		Integer  a5 = 129;
		Integer	 a6 = 129;
		int b1 = 123;
		int b2 = 123;
		int b3 = a3;
//		System.out.println(a5 == a6);
	}

}
